

function setup() {

	createCanvas(400, 400);
}

function draw() {

	background(204);
	for(var i=0;i<35;i++){
		rain(random(0,400),random(15,300));
	}
	for(var j=0;j<8;j++){
		cloud(random(0,400),random(0,60),30);
	}
	//cloud(25,25,25);
	sun(30,-175,50);
	printOff(10);
}

function rain(x, y) {

	push(); // create a new drawing state
	stroke(0,0,255);
	line(x,y,x,y+10);
	pop(); // return the drawing state to it's original state, before the push() function
}
function sun(x,y,l) {
	rectMode(CENTER);
	push();
	translate(width/2, height/2);
	angleMode(RADIANS);
	rotate(PI/3);
	stroke(255,255,0);
	rect(x,y,l,l);
	pop();
}
function printOff(val){
	print("This is random " + val);
}
function cloud(x,y,radius){
	push();
	stroke(235);
	fill(235);
	ellipse(x,y,radius);
	ellipse(x+radius/2,y,radius);
	ellipse(x+radius/4,y,radius);
	scale(1.5);
	ellipse(x+radius/4,y-radius/2,radius);
	pop();
}  
