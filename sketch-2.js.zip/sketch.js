var num = 2;

var x = [];

var y = [];


function setup() {

		createCanvas(400,400);

		background(155);
 		
 		var array = [1,2,3,4];

 		print(x.length);

 		var array2 = [];

 		for(var i = 0; i<4 ; i++){

 		array2[i] = i;
 		
 		}
            }


   noStroke();

      for(var i = 0; i < num; i++) {

         x[i] = 0;

         y[i] = 0;
      }


function draw() {

   background(120);

   for (var i = num-1; i > 0; i--) {

         x[i] = x[i-1];

         y[i] = y[i-1];
   }

   x[0] = mouseX;

   y[0] = mouseY;

   for (var i = 0; i < num; i++) {


      cloud(x[i], y[i]);
       }
   }


function cloud(x,y) {

         noStroke();

         fill(50);  
         
         ellipse(x,y,50,60);
         ellipse(x-10, y+10, 70, 50);
         ellipse(x+10, y+10, 70, 50);  

         var w = x + 10
         var z = y + 55


         for(var j = 0; j < 20; j++)
         {




            x = w;
            y = z;
            w = x + 20;
            z = y + 55;

            stroke(255);

         line(x - 10, y - 20, w, z);

         line(w, z, w - 30, z)

            x = w - 30;
            y = z - 35;
            w = x + 10;
            z = y + 55;

         }
      }





      






