var img1;
var img2;
var img3;

function preload(){

	img1 = loadImage("liluzi.jpeg");
	img2 = loadImage("sunset.jpeg");
	img3 = loadImage("giphy.gif");
}

function setup() {

  createCanvas(1000,1000);
  background(110);
  

}

function draw() {
  
  noStroke();

  fill(85);
  
  textSize(20);

  textFont("Arial");

  text("Hello world!", 100, 200);

  textFont("McLaren");

  text("Lil Uzi is my favorite artist ever", 50, 700, 200, 800);
  
  image(img1, 365, 85);
  image(img2, 365, 600, mouseX, mouseY);
  image(img3, 550, mouseY);

}